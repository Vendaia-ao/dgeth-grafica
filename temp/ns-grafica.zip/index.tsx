

import { bootstrapApplication } from '@angular/platform-browser';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideRouter, withHashLocation, withInMemoryScrolling, Routes } from '@angular/router';
import { AppComponent } from './src/app.component';
import { HomeComponent } from './src/home.component';
import { ServicesComponent } from './src/services.component';
import { PortfolioComponent } from './src/portfolio.component';
import { AboutComponent } from './src/about.component';
import { ContactComponent } from './src/contact.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'servicos', component: ServicesComponent },
  { path: 'portfolio', component: PortfolioComponent },
  { path: 'a-empresa', component: AboutComponent },
  { path: 'contacto', component: ContactComponent },
  { path: '**', redirectTo: '' }
];

bootstrapApplication(AppComponent, {
  providers: [
    provideZonelessChangeDetection(),
    provideRouter(
      routes, 
      withHashLocation(),
      withInMemoryScrolling({
        scrollPositionRestoration: 'top',
        anchorScrolling: 'enabled'
      })
    )
  ]
}).catch((err) => console.error(err));

// AI Studio always uses an `index.tsx` file for all project types.

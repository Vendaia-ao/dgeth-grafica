
import { Component, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ScrollAnimationDirective } from './scroll-animation.directive';

type ProjectCategory = 'Todos' | 'Branding' | 'Editorial' | 'Embalagem' | 'Sinalização';

interface Project {
  id: number;
  client: string;
  title: string;
  category: ProjectCategory;
  image: string;
  size: 'featured' | 'tall' | 'wide' | 'standard'; // Controls grid span
}

@Component({
  selector: 'app-portfolio',
  standalone: true,
  imports: [CommonModule, ScrollAnimationDirective],
  template: `
    <section id="portfolio" class="pt-40 pb-32 relative overflow-hidden min-h-screen">
      
      <!-- Visible Dot Texture Background (Light Mode) -->
      <div class="absolute inset-0 bg-transparent opacity-40 pointer-events-none"
           style="background-image: radial-gradient(#cbd5e1 1.5px, transparent 1.5px); background-size: 24px 24px;">
      </div>

      <div class="container mx-auto px-6 relative z-10">
        
        <!-- Header & Filter Section -->
        <div class="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-12" appScrollAnimation animationClass="reveal-up animate-active">
          <div class="max-w-2xl">
            <span class="block text-ns-blue font-bold tracking-[0.2em] text-sm mb-4 uppercase">Nossa Curadoria</span>
            <h2 class="text-5xl md:text-7xl font-display font-black text-slate-900 leading-[0.9]">
              Onde a técnica <br>
              <span class="font-serif italic font-light text-slate-400">encontra a arte.</span>
            </h2>
          </div>

          <!-- Filter Menu -->
          <nav class="flex flex-wrap gap-x-8 gap-y-4 md:justify-end stagger-parent" appScrollAnimation animationClass="animate-active">
            @for (cat of categories; track cat) {
              <button 
                (click)="activeCategory.set(cat)"
                class="stagger-item text-lg md:text-xl font-bold transition-all duration-300 relative group"
                [class.text-ns-blue]="activeCategory() === cat"
                [class.text-slate-300]="activeCategory() !== cat">
                {{cat}}
                <span class="absolute -bottom-1 left-0 h-0.5 bg-ns-blue transition-all duration-300"
                      [class.w-full]="activeCategory() === cat"
                      [class.w-0]="activeCategory() !== cat"
                      [class.group-hover:w-full]="activeCategory() !== cat"></span>
              </button>
            }
          </nav>
        </div>

        <!-- Masonry Grid -->
        <div class="grid grid-cols-1 md:grid-cols-12 gap-8 auto-rows-[400px]">
          
          @for (project of filteredProjects(); track project.id) {
            <article class="group relative overflow-hidden rounded-lg cursor-pointer transition-all duration-700 hover:shadow-2xl bg-white shadow-sm border border-slate-100 hover:z-10"
                     [ngClass]="getSizeClasses(project.size)"
                     appScrollAnimation animationClass="reveal-mask-up animate-active"
                     [delay]="$index * 50">
              
              <!-- Image with Zoom Effect -->
              <img [src]="project.image" [alt]="project.title" 
                   class="w-full h-full object-cover transition-transform duration-[1.2s] ease-out-expo group-hover:scale-110 filter grayscale-[10%] group-hover:grayscale-0">
              
              <!-- Overlay -->
              <div class="absolute inset-0 bg-gradient-to-t from-ns-dark/90 via-ns-dark/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-8">
                
                <div class="transform translate-y-8 group-hover:translate-y-0 transition-transform duration-500 ease-out-back delay-100">
                  <div class="flex items-center gap-3 mb-2">
                    <span class="px-2 py-1 bg-ns-blue text-white text-[10px] font-bold uppercase tracking-widest rounded-sm">
                      {{project.category}}
                    </span>
                    <span class="h-px w-8 bg-white/50"></span>
                    <span class="text-slate-300 text-xs uppercase tracking-wider font-semibold">{{project.client}}</span>
                  </div>
                  
                  <h3 class="text-3xl font-display font-bold text-white leading-none mb-4">
                    {{project.title}}
                  </h3>
                  
                  <div class="flex items-center gap-2 text-ns-yellow text-sm font-bold uppercase tracking-wider group/link">
                    Ver Detalhes
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 transform transition-transform group-hover/link:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                  </div>
                </div>
              </div>

              <!-- Default State Label (Visible when not hovering, fades out on hover) -->
              <div class="absolute bottom-6 left-6 md:opacity-100 group-hover:opacity-0 transition-all duration-300 md:block hidden transform group-hover:translate-y-4">
                 <h4 class="text-white drop-shadow-md font-display font-bold text-xl">{{project.title}}</h4>
              </div>

            </article>
          }

        </div>

        <!-- Load More / CTA -->
        <div class="mt-20 text-center" appScrollAnimation animationClass="reveal-up animate-active">
          <p class="text-slate-400 mb-6">Mostrando seleção de trabalhos recentes</p>
          <a href="/contacto" class="inline-block border-b-2 border-ns-dark text-ns-dark font-black text-2xl hover:text-ns-blue hover:border-ns-blue transition-colors pb-1">
            Iniciar um projeto similar
          </a>
        </div>

      </div>
    </section>
  `,
  styles: [`
    :host {
      display: block;
    }
  `]
})
export class PortfolioComponent {
  categories: ProjectCategory[] = ['Todos', 'Branding', 'Editorial', 'Embalagem', 'Sinalização'];
  activeCategory = signal<ProjectCategory>('Todos');

  projects = signal<Project[]>([
    {
      id: 1,
      client: 'VAPTY Logística',
      title: 'Identidade em Movimento',
      category: 'Sinalização',
      image: 'https://images.unsplash.com/photo-1629427042301-38aa7363404c?q=80&w=1200&auto=format&fit=crop', // Truck/Fleet
      size: 'featured'
    },
    {
      id: 2,
      client: 'Revista EGO',
      title: 'Edição de Aniversário',
      category: 'Editorial',
      image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?q=80&w=800&auto=format&fit=crop', // Book/Magazine
      size: 'tall'
    },
    {
      id: 3,
      client: 'Café Origem',
      title: 'Packaging Sustentável',
      category: 'Embalagem',
      image: 'https://images.unsplash.com/photo-1632515902189-e1cd3f274a13?q=80&w=800&auto=format&fit=crop', // Packaging
      size: 'standard'
    },
    {
      id: 4,
      client: 'BRAINS Tech',
      title: 'Rebranding Corporativo',
      category: 'Branding',
      image: 'https://images.unsplash.com/photo-1600607686527-6fb886090705?q=80&w=800&auto=format&fit=crop', // Stationery
      size: 'standard'
    },
    {
      id: 5,
      client: 'Green Lar',
      title: 'Sinalização de Ambientes',
      category: 'Sinalização',
      image: 'https://images.unsplash.com/photo-1564510714747-6d32a49852fc?q=80&w=1200&auto=format&fit=crop', // Signage interior
      size: 'wide'
    },
    {
      id: 6,
      client: 'NS Gráfica',
      title: 'Acabamentos de Luxo',
      category: 'Editorial',
      image: 'https://images.unsplash.com/photo-1605647540924-852290f6b0d5?q=80&w=800&auto=format&fit=crop', // Texture paper
      size: 'standard'
    }
  ]);

  filteredProjects = computed(() => {
    const category = this.activeCategory();
    if (category === 'Todos') {
      return this.projects();
    }
    return this.projects().filter(p => p.category === category);
  });

  getSizeClasses(size: Project['size']): string {
    switch (size) {
      case 'featured': return 'md:col-span-8 md:row-span-2';
      case 'tall': return 'md:col-span-4 md:row-span-2';
      case 'wide': return 'md:col-span-8 md:row-span-1';
      case 'standard': return 'md:col-span-4 md:row-span-1';
      default: return 'md:col-span-4 md:row-span-1';
    }
  }
}


import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ScrollAnimationDirective } from './scroll-animation.directive';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, RouterModule, ScrollAnimationDirective],
  template: `
    <section class="min-h-screen pt-40 pb-24 relative z-10">
      
      <!-- Page Header -->
      <div class="container mx-auto px-6 mb-16" appScrollAnimation animationClass="reveal-up animate-active">
        <div class="max-w-4xl">
          <span class="block text-ns-blue font-bold tracking-[0.2em] text-sm mb-6 uppercase">
            Fale Connosco
          </span>
          <h1 class="font-display font-black text-5xl md:text-7xl text-slate-900 leading-[0.9] mb-8 tracking-tight">
            Vamos iniciar o seu <br>
            <span class="text-transparent bg-clip-text bg-gradient-to-r from-ns-blue to-ns-cyan font-serif italic font-light">próximo projeto?</span>
          </h1>
          <p class="text-xl text-slate-600 max-w-2xl leading-relaxed font-light border-l-2 border-ns-yellow pl-6">
            Estamos prontos para ouvir suas ideias e transformá-las em realidade impressa. Escolha o canal que preferir.
          </p>
        </div>
      </div>

      <div class="container mx-auto px-6">
        <div class="flex flex-col lg:flex-row gap-16">
          
          <!-- Contact Info Column -->
          <div class="lg:w-1/3 space-y-8 stagger-parent" appScrollAnimation animationClass="animate-active">
            <div class="space-y-6">
               <!-- WhatsApp Card -->
               <a href="https://wa.me/244929199330" target="_blank" class="stagger-item flex items-center gap-4 group cursor-pointer p-6 rounded-2xl bg-white shadow-sm hover:shadow-xl transition-all border border-slate-100 hover:border-ns-blue/20 transform hover:-translate-y-1">
                 <div class="w-14 h-14 rounded-full bg-[#25D366]/10 flex items-center justify-center text-[#25D366] group-hover:scale-110 transition-transform">
                    <svg class="w-7 h-7" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.008-.57-.008-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
                 </div>
                 <div>
                   <p class="text-xs text-slate-400 uppercase tracking-wider font-bold">WhatsApp (Prioritário)</p>
                   <p class="text-xl font-bold text-slate-900">Falar Agora</p>
                 </div>
               </a>
               
               <!-- Email Card -->
               <div class="stagger-item flex items-center gap-4 group p-6 rounded-2xl bg-white shadow-sm border border-slate-100">
                 <div class="w-14 h-14 rounded-full bg-blue-50 flex items-center justify-center text-ns-blue">
                   <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                 </div>
                 <div>
                   <p class="text-xs text-slate-400 uppercase tracking-wider font-bold">Email</p>
                   <p class="text-lg font-semibold text-slate-900 break-all">comercial@nsgrafica.ao</p>
                 </div>
               </div>

               <!-- Location Card -->
               <div class="stagger-item flex items-center gap-4 group p-6 rounded-2xl bg-white shadow-sm border border-slate-100">
                 <div class="w-14 h-14 rounded-full bg-blue-50 flex items-center justify-center text-ns-blue">
                   <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                 </div>
                 <div>
                   <p class="text-xs text-slate-400 uppercase tracking-wider font-bold">Localização</p>
                   <p class="text-lg font-semibold text-slate-900">Maianga, Rua Augusto Tadeu Basto, Edifício Nº30</p>
                 </div>
               </div>

                <!-- Phone Card -->
               <div class="stagger-item flex items-center gap-4 group p-6 rounded-2xl bg-white shadow-sm border border-slate-100">
                 <div class="w-14 h-14 rounded-full bg-blue-50 flex items-center justify-center text-ns-blue">
                   <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                 </div>
                 <div>
                   <p class="text-xs text-slate-400 uppercase tracking-wider font-bold">Telefones</p>
                   <p class="text-lg font-semibold text-slate-900">929 199 330 <span class="text-slate-300 mx-1">|</span> 922 530 082</p>
                 </div>
               </div>
            </div>
          </div>
          
          <!-- Contact Form -->
          <div class="lg:w-2/3" appScrollAnimation animationClass="reveal-scale animate-active" [delay]="200">
            <div class="bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-slate-100 hover:shadow-2xl transition-shadow duration-500">
              <h3 class="text-2xl font-display font-bold text-slate-900 mb-6">Envie um pedido de orçamento</h3>
              
              <form class="space-y-6" (submit)="$event.preventDefault()">
                <div class="grid md:grid-cols-2 gap-6">
                   <div class="space-y-2">
                     <label class="text-slate-500 text-xs font-bold uppercase tracking-wider ml-1">Nome Completo</label>
                     <input type="text" class="w-full px-4 py-4 bg-[#F5F6FA] border border-slate-200 rounded-lg focus:ring-2 focus:ring-ns-blue focus:border-transparent outline-none transition-all text-slate-800 font-medium focus:scale-[1.01] duration-300" placeholder="Seu nome">
                   </div>
                   <div class="space-y-2">
                     <label class="text-slate-500 text-xs font-bold uppercase tracking-wider ml-1">Telefone / WhatsApp</label>
                     <input type="tel" class="w-full px-4 py-4 bg-[#F5F6FA] border border-slate-200 rounded-lg focus:ring-2 focus:ring-ns-blue focus:border-transparent outline-none transition-all text-slate-800 font-medium focus:scale-[1.01] duration-300" placeholder="Seu contacto">
                   </div>
                </div>

                <div class="space-y-2">
                   <label class="text-slate-500 text-xs font-bold uppercase tracking-wider ml-1">Email (Opcional)</label>
                   <input type="email" class="w-full px-4 py-4 bg-[#F5F6FA] border border-slate-200 rounded-lg focus:ring-2 focus:ring-ns-blue focus:border-transparent outline-none transition-all text-slate-800 font-medium focus:scale-[1.01] duration-300" placeholder="seu@email.com">
                 </div>
                
                <div class="space-y-2">
                   <label class="text-slate-500 text-xs font-bold uppercase tracking-wider ml-1">Mensagem ou Detalhes do Projeto</label>
                   <textarea rows="6" class="w-full px-4 py-4 bg-[#F5F6FA] border border-slate-200 rounded-lg focus:ring-2 focus:ring-ns-blue focus:border-transparent outline-none transition-all text-slate-800 font-medium resize-none focus:scale-[1.01] duration-300" placeholder="Conte-nos sobre o que precisa imprimir, quantidades ou ideias..."></textarea>
                </div>

                <div class="flex justify-end pt-4">
                   <button class="w-full md:w-auto px-10 py-5 bg-ns-blue hover:bg-ns-dark text-white font-bold text-lg rounded-xl transition-all shadow-lg shadow-blue-500/30 transform hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-3">
                     <span>Enviar Pedido</span>
                     <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                       <path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd" />
                     </svg>
                   </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  `,
  styles: [`
    :host { display: block; }
  `]
})
export class ContactComponent {}


import { Component, ElementRef, ViewChildren, QueryList, AfterViewInit, signal, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { ScrollAnimationDirective } from './scroll-animation.directive';

@Component({
  selector: 'app-services',
  standalone: true,
  imports: [CommonModule, ScrollAnimationDirective],
  template: `
    <!-- Dark Section (Standalone Page) -->
    <section id="services" class="relative min-h-screen pt-32 pb-40 z-20">
      
      <!-- Full Page Background -->
      <div class="absolute inset-0 bg-slate-900 -z-10 shadow-2xl overflow-hidden">
        <!-- Visible Tech Grid Texture -->
        <div class="absolute inset-0 opacity-[0.07]" 
             style="background-image: linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px); background-size: 40px 40px;">
        </div>
        <!-- Deep Glow -->
        <div class="absolute top-0 right-0 w-[50vw] h-[50vw] bg-ns-blue opacity-20 blur-[120px] rounded-full mix-blend-screen animate-pulse-slow"></div>
      </div>

      <div class="container mx-auto px-6 relative z-10">
        <!-- Header Section -->
        <div class="mb-32 max-w-4xl" appScrollAnimation animationClass="reveal-up animate-active">
          <span class="block text-ns-cyan font-bold tracking-[0.2em] text-sm mb-4 uppercase">Expertise Técnica</span>
          <h2 class="text-5xl md:text-7xl font-display font-black text-white leading-[0.9] mb-8">
            Nós materializamos <br>
            <span class="text-transparent bg-clip-text bg-gradient-to-r from-ns-cyan to-white italic font-serif font-light pr-4">o intangível.</span>
          </h2>
          <p class="text-xl text-slate-300 max-w-xl leading-relaxed">
            Unimos engenharia gráfica de precisão com design estratégico para entregar produtos que não são apenas impressos, são experiências.
          </p>
        </div>

        <!-- Services List (Deconstructed Layout) -->
        <div class="flex flex-col gap-32 md:gap-48">
          
          @for (service of services(); track service.id; let i = $index) {
            <div class="group relative grid grid-cols-1 md:grid-cols-12 gap-8 items-center"
                 appScrollAnimation animationClass="reveal-up animate-active">
              
              <!-- Number Watermark (Dark Mode Style) -->
              <div class="hidden md:block absolute -top-20 font-display font-black text-[12rem] text-outline-light opacity-10 select-none z-0 transition-transform duration-700 group-hover:translate-x-4"
                   [class.left-0]="i % 2 === 0"
                   [class.right-0]="i % 2 !== 0">
                0{{i + 1}}
              </div>

              <!-- Content Column -->
              <div class="relative z-10"
                   [class.md:col-span-5]="true"
                   [class.md:col-start-1]="i % 2 === 0"
                   [class.md:col-start-8]="i % 2 !== 0"
                   [class.md:row-start-1]="true"
                   [class.order-2]="i % 2 !== 0"
                   [class.md:order-1]="i % 2 === 0">
                
                <h3 class="text-3xl md:text-5xl font-display font-bold text-white mb-6 group-hover:text-ns-cyan transition-colors">
                  {{service.title}}
                </h3>
                
                <div class="h-1 w-20 bg-ns-yellow mb-8 transform origin-left group-hover:scale-x-150 transition-transform duration-500 ease-out-expo"></div>

                <p class="text-lg text-slate-300 mb-8 leading-relaxed font-light">
                  {{service.description}}
                </p>

                <ul class="space-y-3 mb-10 stagger-parent" appScrollAnimation animationClass="animate-active">
                  @for (feature of service.features; track feature) {
                    <li class="stagger-item flex items-center gap-3 text-slate-400 text-sm font-semibold tracking-wide">
                      <span class="w-1.5 h-1.5 rounded-full bg-ns-cyan animate-pulse"></span>
                      {{feature}}
                    </li>
                  }
                </ul>

                <a href="/contacto" class="inline-flex items-center gap-3 text-ns-cyan font-bold uppercase tracking-wider text-sm hover:gap-5 transition-all duration-300">
                  Solicitar Orçamento
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </a>
              </div>

              <!-- Image Column -->
              <div class="relative z-10"
                   [class.md:col-span-6]="true"
                   [class.md:col-start-7]="i % 2 === 0"
                   [class.md:col-start-1]="i % 2 !== 0"
                   [class.md:row-start-1]="true"
                   [class.order-1]="i % 2 !== 0"
                   [class.md:order-2]="i % 2 === 0">
                
                <div class="relative aspect-[4/5] md:aspect-[3/4] group-hover:z-20 transition-all duration-500">
                  <!-- Decorative Shape -->
                  <div class="absolute inset-0 bg-ns-cyan/20 transform transition-transform duration-700 ease-out"
                       [class.translate-x-4]="i % 2 === 0"
                       [class.translate-y-4]="i % 2 === 0"
                       [class.-translate-x-4]="i % 2 !== 0"
                       [class.translate-y-4]="i % 2 !== 0"
                       [class.group-hover:translate-x-8]="i % 2 === 0"
                       [class.group-hover:-translate-x-8]="i % 2 !== 0">
                  </div>

                  <!-- Main Image -->
                  <div class="absolute inset-0 overflow-hidden rounded shadow-2xl transform transition-transform duration-700 ease-out-expo group-hover:scale-[1.02] border border-white/10"
                       [class.rotate-2]="i % 2 === 0"
                       [class.-rotate-2]="i % 2 !== 0"
                       [class.group-hover:rotate-0]="true">
                    <img [src]="service.image" [alt]="service.title" class="w-full h-full object-cover filter grayscale-[40%] group-hover:grayscale-0 transition-all duration-700">
                    
                    <!-- Overlay Gradient -->
                    <div class="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent opacity-60 group-hover:opacity-30 transition-opacity duration-500"></div>
                  </div>

                  <!-- Floating Detail Card -->
                  <div class="absolute bg-slate-800/90 backdrop-blur p-4 rounded shadow-xl max-w-[180px] hidden md:block transform transition-transform duration-500 group-hover:-translate-y-2 border border-white/10"
                       [class.bottom-8]="true"
                       [class.-left-8]="i % 2 === 0"
                       [class.-right-8]="i % 2 !== 0">
                     <span class="block text-ns-cyan text-xs font-bold uppercase mb-1">{{service.highlightTitle}}</span>
                     <span class="block text-slate-200 text-xs leading-tight">{{service.highlightText}}</span>
                  </div>
                </div>
              </div>

            </div>
          }
        </div>

        <!-- Final CTA Block -->
        <div class="mt-32 relative bg-gradient-to-br from-ns-blue to-ns-dark rounded-3xl p-12 md:p-24 overflow-hidden text-center border border-white/10"
             appScrollAnimation animationClass="reveal-scale animate-active">
           <div class="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] animate-float-slow"></div>
           <div class="relative z-10">
             <h3 class="text-3xl md:text-5xl font-display font-bold text-white mb-6">Pronto para elevar sua marca?</h3>
             <p class="text-blue-100 text-lg mb-10 max-w-2xl mx-auto">Nossa equipe de especialistas está aguardando seu desafio. Vamos criar algo único.</p>
             <a href="/contacto" class="inline-block px-10 py-4 bg-ns-yellow text-slate-900 font-bold rounded-full hover:bg-white transition-all transform hover:scale-105 shadow-lg animate-pulse-slow">
               Iniciar Projeto Agora
             </a>
           </div>
        </div>

      </div>
    </section>
  `,
  styles: [`
    .text-outline-light {
      -webkit-text-stroke: 2px rgba(255,255,255,0.1);
      color: transparent;
    }
  `]
})
export class ServicesComponent {
  
  services = signal([
    {
      id: 1,
      title: 'Design Gráfico & Identidade',
      description: 'Não fazemos apenas logotipos; construímos ecossistemas visuais. Do conceito abstrato à aplicação prática, nossa equipe de design traduz a essência da sua empresa em uma linguagem visual coerente e impactante.',
      features: ['Identidade Visual Corporativa', 'Rebranding Estratégico', 'Design Editorial', 'Embalagens (Packaging)'],
      image: 'https://images.unsplash.com/photo-1626785774573-4b7993155853?q=80&w=800&auto=format&fit=crop',
      highlightTitle: 'Foco no detalhe',
      highlightText: 'Tipografia exclusiva e paletas de cores estudadas.',
    },
    {
      id: 2,
      title: 'Impressão Offset Industrial',
      description: 'Para quem joga grande. Nossa infraestrutura Offset Heidelberg garante fidelidade absoluta de cores e acabamentos premium para grandes tiragens, com um custo-benefício imbatível.',
      features: ['Revistas e Catálogos', 'Papelaria Institucional', 'Folders de Alta Tiragem', 'Acabamentos Especiais (Hot Stamping, Verniz)'],
      image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?q=80&w=800&auto=format&fit=crop', // Printing press style
      highlightTitle: 'Capacidade',
      highlightText: 'Até 50.000 impressões/hora com precisão milimétrica.',
    },
    {
      id: 3,
      title: 'Comunicação Visual',
      description: 'Sua marca ocupando o espaço físico. Desenvolvemos soluções de grande formato que transformam fachadas, frotas e ambientes internos em poderosos pontos de contato com seu cliente.',
      features: ['Fachadas em ACM e Lona', 'Adesivagem de Frotas', 'Sinalização Interna e Externa', 'Banners e Outdoors'],
      image: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?q=80&w=800&auto=format&fit=crop', // Office/Signage
      highlightTitle: 'Durabilidade',
      highlightText: 'Materiais resistentes a intempéries e proteção UV.',
    },
    {
      id: 4,
      title: 'Brindes Corporativos',
      description: 'O marketing que seu cliente leva para casa. Personalizamos itens úteis e sofisticados que mantêm sua marca presente no dia a dia das pessoas importantes para o seu negócio.',
      features: ['Kits Onboarding', 'Agendas e Cadernos Premium', 'Canetas Personalizadas', 'Têxtil e Uniformes'],
      image: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?q=80&w=800&auto=format&fit=crop', // Gift box
      highlightTitle: 'Personalização',
      highlightText: 'Técnicas de gravação a laser e serigrafia HD.',
    }
  ]);
}

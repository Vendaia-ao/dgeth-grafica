
import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ScrollAnimationDirective } from './scroll-animation.directive';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule, RouterModule, ScrollAnimationDirective],
  template: `
    <!-- 1. HERO EDITORIAL -->
    <section class="pt-48 pb-32 relative z-10 min-h-[60vh] flex flex-col justify-center">
      <div class="container mx-auto px-6">
        <div class="max-w-4xl" appScrollAnimation animationClass="reveal-up animate-active">
          <span class="block text-ns-blue font-bold tracking-[0.2em] text-xs md:text-sm mb-6 uppercase">
            Manifesto NS Gráfica
          </span>
          <h1 class="font-display font-black text-5xl md:text-7xl lg:text-8xl text-slate-900 leading-[0.9] mb-10 tracking-tight">
            Mais do que imprimir, <br>
            damos <span class="font-serif italic font-light text-slate-500">forma</span> às ideias.
          </h1>
          <p class="text-xl md:text-2xl text-slate-600 max-w-2xl leading-relaxed font-light border-l-2 border-ns-yellow pl-6">
            Não somos apenas executores. Somos parceiros estratégicos na materialização da identidade visual da sua empresa.
          </p>
        </div>
      </div>
    </section>

    <!-- 2. HISTÓRIA (NARRATIVA) -->
    <section class="py-24 relative z-10">
      <div class="container mx-auto px-6">
        <div class="grid md:grid-cols-12 gap-12 items-start">
          <!-- Abstract Line Visual -->
          <div class="hidden md:block md:col-span-3 lg:col-span-4 relative h-full min-h-[200px]" appScrollAnimation animationClass="reveal-mask-up animate-active">
             <div class="absolute top-0 left-0 w-[1px] h-full bg-gradient-to-b from-ns-blue to-transparent"></div>
             <div class="absolute top-0 left-[-4px] w-2 h-2 rounded-full bg-ns-blue"></div>
          </div>
          
          <div class="md:col-span-9 lg:col-span-6" appScrollAnimation animationClass="reveal-up animate-active" [delay]="100">
            <h2 class="text-3xl font-display font-bold text-slate-900 mb-8">Nossa Trajetória</h2>
            <div class="space-y-6 text-lg text-slate-600 leading-relaxed">
              <p>
                A NS Gráfica nasceu de uma inquietação: o mercado estava cheio de gráficas rápidas, mas vazio de cuidado artesanal. Percebemos que empresas de alto padrão precisavam de materiais que refletissem, no papel e no ambiente, a mesma excelência que entregam em seus serviços.
              </p>
              <p>
                Ao longo dos anos, investimos pesado não apenas em máquinas Heidelberg de última geração, mas em pessoas que têm o "olho gráfico". Aquela capacidade de perceber um milímetro de diferença ou um ajuste sutil de cor que muda tudo.
              </p>
              <p class="font-semibold text-slate-900">
                Hoje, somos a escolha de quem não aceita o "padrão". Somos a casa das marcas que exigem perfeição.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- 3. VALORES (O QUE NOS MOVE) -->
    <section class="py-32 bg-white relative z-10 border-y border-slate-100">
      <div class="container mx-auto px-6">
        <div class="mb-16" appScrollAnimation animationClass="reveal-scale animate-active">
           <span class="text-ns-blue font-bold tracking-[0.2em] text-xs uppercase mb-2 block">Cultura</span>
           <h2 class="text-4xl font-display font-bold text-slate-900">O que é inegociável</h2>
        </div>

        <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-8 stagger-parent" appScrollAnimation animationClass="animate-active">
          @for (val of values(); track val.title) {
            <div class="stagger-item group p-8 border border-slate-100 hover:border-ns-blue/30 transition-all duration-500 bg-[#F5F6FA] rounded-xl hover:shadow-lg hover:-translate-y-1">
              <h3 class="text-xl font-bold text-slate-900 mb-4 group-hover:text-ns-blue transition-colors">
                {{val.title}}
              </h3>
              <p class="text-slate-500 text-sm leading-relaxed">
                {{val.desc}}
              </p>
            </div>
          }
        </div>
      </div>
    </section>

    <!-- 4. PROCESSO (COMO TRABALHAMOS) -->
    <section class="py-32 relative z-10">
      <div class="container mx-auto px-6">
        <div class="grid lg:grid-cols-12 gap-16">
          <div class="lg:col-span-4" appScrollAnimation animationClass="reveal-mask-left animate-active">
            <h2 class="text-4xl font-display font-bold text-slate-900 mb-6">Processo Fluido</h2>
            <p class="text-slate-600 mb-8">
              Eliminamos a burocracia desnecessária. Nosso fluxo é desenhado para garantir precisão técnica sem travar o seu cronograma.
            </p>
            <div class="hidden lg:block w-16 h-1 bg-ns-yellow"></div>
          </div>

          <div class="lg:col-span-8">
            <div class="grid md:grid-cols-2 gap-x-12 gap-y-16 stagger-parent" appScrollAnimation animationClass="animate-active">
              @for (step of steps(); track step.id) {
                <div class="stagger-item relative pl-8 border-l border-slate-200">
                  <span class="absolute -left-[9px] top-0 w-[18px] h-[18px] rounded-full bg-[#F5F6FA] border-4 border-ns-blue"></span>
                  <span class="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Passo 0{{step.id}}</span>
                  <h4 class="text-2xl font-bold text-slate-900 mb-3">{{step.title}}</h4>
                  <p class="text-slate-500 text-sm leading-relaxed">{{step.desc}}</p>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- 5. DIFERENCIAL HUMANO (QUOTE) -->
    <section class="py-24 bg-slate-900 text-white relative overflow-hidden" appScrollAnimation animationClass="reveal-scale animate-active">
      <!-- Texture overlay -->
      <div class="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] animate-pulse-slow"></div>
      
      <div class="container mx-auto px-6 relative z-10 text-center">
        <div class="max-w-3xl mx-auto">
          <svg class="w-12 h-12 text-ns-cyan mx-auto mb-8 opacity-50" fill="currentColor" viewBox="0 0 24 24">
            <path d="M14.017 21L14.017 18C14.017 16.8954 13.1216 16 12.017 16H9L9.00003 12.3789C15.025 12.3789 15.025 3 9.00003 3H3V12.3789H6.28998C6.67069 13.7144 7.69165 14.7354 9.02717 15.1161V21H14.017ZM21 21L21 18C21 16.8954 20.1046 16 19 16H15.983L15.983 12.3789C22.008 12.3789 22.008 3 15.983 3H9.98297V12.3789H13.273C13.6537 13.7144 14.6747 14.7354 16.0102 15.1161V21H21Z" />
          </svg>
          <p class="text-2xl md:text-4xl font-display font-medium leading-tight mb-8">
            "Tecnologia imprime, mas é o <span class="text-ns-cyan italic font-serif">olhar humano</span> que garante a excelência. Cada projeto passa pela mão e pelo crivo de quem ama o que faz."
          </p>
          <div class="w-20 h-[1px] bg-slate-700 mx-auto"></div>
        </div>
      </div>
    </section>

    <!-- 6. CTA FINAL -->
    <section class="py-32 relative z-10 text-center">
      <div class="container mx-auto px-6" appScrollAnimation animationClass="reveal-up animate-active">
        <h2 class="text-4xl md:text-5xl font-display font-black text-slate-900 mb-8">
          Vamos dar forma à sua <br>próxima ideia?
        </h2>
        <a routerLink="/contacto" class="inline-flex items-center gap-3 px-10 py-4 bg-ns-blue text-white font-bold rounded-full hover:bg-ns-dark transition-all transform hover:scale-105 shadow-xl shadow-blue-500/20">
          Solicitar Orçamento
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
          </svg>
        </a>
      </div>
    </section>
  `
})
export class AboutComponent {
  values = signal([
    {
      title: 'Qualidade sem atalhos',
      desc: 'Não economizamos em insumos ou tempo de máquina. Se não estiver perfeito, fazemos de novo.'
    },
    {
      title: 'Atenção ao detalhe',
      desc: 'Do alinhamento milimétrico à fidelidade da cor Pantone. O detalhe é onde a marca vive.'
    },
    {
      title: 'Parceria Real',
      desc: 'Não somos apenas fornecedores. Entendemos o seu negócio para sugerir as melhores soluções.'
    },
    {
      title: 'Compromisso',
      desc: 'Prazo é sagrado. Entendemos a urgência do mercado e honramos cada data combinada.'
    }
  ]);

  steps = signal([
    {
      id: 1,
      title: 'Entendimento',
      desc: 'Ouvimos sua necessidade e analisamos os arquivos técnicos para garantir viabilidade.'
    },
    {
      id: 2,
      title: 'Criação & Pré-impressão',
      desc: 'Ajustes finos, provas de cor e preparação de matrizes para garantir fidelidade.'
    },
    {
      id: 3,
      title: 'Produção Premium',
      desc: 'Execução em maquinário de ponta com supervisão constante de qualidade.'
    },
    {
      id: 4,
      title: 'Entrega Técnica',
      desc: 'Acabamento, embalagem segura e logística para chegar perfeito até você.'
    }
  ]);
}


import { Directive, ElementRef, Input, AfterViewInit, OnDestroy, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appScrollAnimation]',
  standalone: true
})
export class ScrollAnimationDirective implements AfterViewInit, OnDestroy {
  @Input() animationClass: string = 'animate-active';
  @Input() threshold: number = 0.15;
  @Input() delay: number = 0;

  private observer: IntersectionObserver | null = null;

  constructor(private el: ElementRef, private renderer: Renderer2) {}

  ngAfterViewInit() {
    this.renderer.addClass(this.el.nativeElement, 'scroll-animate-init');

    if (this.delay > 0) {
      this.renderer.setStyle(this.el.nativeElement, 'transition-delay', `${this.delay}ms`);
      this.renderer.setStyle(this.el.nativeElement, 'animation-delay', `${this.delay}ms`);
    }

    // Fix: Split by any whitespace regex to handle multiple spaces, tabs, newlines safely
    const rawClasses = this.animationClass.trim().split(/\s+/);
    
    // Separate setup classes (like 'reveal-up') which must be present initially for the transform origin
    // from trigger classes (like 'animate-active') which trigger the transition.
    const setupClasses = rawClasses.filter(c => c && c.startsWith('reveal-'));
    const triggerClasses = rawClasses.filter(c => c && !c.startsWith('reveal-'));

    // Apply setup classes immediately so the element is in the correct "before" state (e.g. translateY(60px))
    setupClasses.forEach(c => {
        this.renderer.addClass(this.el.nativeElement, c);
    });

    const options = {
      root: null,
      rootMargin: '0px',
      threshold: this.threshold
    };

    this.observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          // Apply trigger classes on scroll to start the animation
          triggerClasses.forEach(c => {
             this.renderer.addClass(this.el.nativeElement, c);
          });

          if (this.observer) this.observer.unobserve(this.el.nativeElement); // Trigger once
        }
      });
    }, options);

    this.observer.observe(this.el.nativeElement);
  }

  ngOnDestroy() {
    if (this.observer) {
      this.observer.disconnect();
    }
  }
}


import { Component, signal, computed, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-background',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="fixed inset-0 w-full h-full pointer-events-none overflow-hidden -z-50 bg-[#F5F6FA]">
      
      <!-- 1. Noise Texture (Simulating Premium Paper) -->
      <div class="absolute inset-0 opacity-[0.04] mix-blend-overlay noise-bg"></div>

      <!-- 2. Decorative Organic Shapes -->
      <!-- Shape A: Top Left (Organic Blob) -->
      <div class="absolute -top-[10%] -left-[10%] w-[50vw] h-[50vw] rounded-full bg-ns-blue opacity-[0.07] blur-[80px] animate-float-slow"></div>
      
      <!-- Shape B: Bottom Right (Geometric) -->
      <div class="absolute -bottom-[5%] -right-[5%] w-[40vw] h-[40vw] rounded-full bg-[#003366] opacity-[0.05] blur-[100px]"></div>

      <!-- 3. Subtle Particles -->
      @for (p of particles(); track $index) {
        <div class="absolute rounded-full bg-slate-400 opacity-20 animate-particle-float"
             [style.left.%]="p.left"
             [style.top.%]="p.top"
             [style.width.px]="p.size"
             [style.height.px]="p.size"
             [style.animation-duration.s]="p.duration"
             [style.animation-delay.s]="p.delay">
        </div>
      }
    </div>
  `,
  styles: [`
    .noise-bg {
      background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E");
    }

    @keyframes particleFloat {
      0% {
        transform: translateY(0) translateX(0);
        opacity: 0;
      }
      10% {
        opacity: 0.2;
      }
      90% {
        opacity: 0.2;
      }
      100% {
        transform: translateY(-100px) translateX(20px);
        opacity: 0;
      }
    }

    .animate-particle-float {
      animation-name: particleFloat;
      animation-timing-function: linear;
      animation-iteration-count: infinite;
      animation-fill-mode: both;
    }
    
    @keyframes floatSlow {
      0%, 100% { transform: translate(0, 0) scale(1); }
      33% { transform: translate(30px, -30px) scale(1.05); }
      66% { transform: translate(-20px, 20px) scale(0.95); }
    }
    
    .animate-float-slow {
      animation: floatSlow 20s ease-in-out infinite;
    }
  `],
  encapsulation: ViewEncapsulation.None
})
export class BackgroundComponent {
  particles = signal<any[]>([]);

  constructor() {
    this.generateParticles();
  }

  generateParticles() {
    const count = 12; // Max particles as per requirement
    const newParticles = [];
    
    for (let i = 0; i < count; i++) {
      newParticles.push({
        left: Math.random() * 100,
        top: Math.random() * 100, // Initial static position, animation moves relative
        size: Math.random() * 2 + 2, // 2px - 4px
        duration: Math.random() * 12 + 18, // 18s - 30s
        delay: Math.random() * -30 // Start at random times
      });
    }
    
    this.particles.set(newParticles);
  }
}

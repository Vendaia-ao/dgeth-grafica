
import { Component, signal, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ScrollAnimationDirective } from './scroll-animation.directive';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule, ScrollAnimationDirective],
  template: `
    <!-- 1. HERO SECTION - KINETIC TYPOGRAPHY -->
    <section id="home" class="relative h-screen w-full overflow-hidden bg-transparent flex items-center justify-center">
      <!-- Interactive Background Abstract Layer -->
      <div class="absolute inset-0 z-0 opacity-10 pointer-events-none overflow-hidden" 
           [style.transform]="'translate(' + mouseX() * -0.5 + 'px, ' + mouseY() * -0.5 + 'px)'">
        <svg viewBox="0 0 800 800" class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[150vmax] h-[150vmax] animate-spin-slow text-ns-blue fill-current">
            <path d="M400 0 L800 200 L800 600 L400 800 L0 600 L0 200 Z" stroke="currentColor" stroke-width="2" fill="none" />
            <circle cx="400" cy="400" r="300" stroke="currentColor" stroke-width="1" fill="none" class="opacity-50" />
        </svg>
      </div>
      
      <!-- Content Grid -->
      <div class="container mx-auto px-6 h-full pt-20 relative z-10">
        <div class="grid grid-cols-6 md:grid-cols-12 grid-rows-6 h-full w-full pointer-events-none">
          
          <!-- Word 1: IDEIAS (Split Character Animation) -->
          <div class="col-span-6 md:col-span-7 row-start-2 md:row-start-2 flex items-end">
            <h1 class="font-display font-black text-6xl md:text-8xl lg:text-9xl text-slate-900 tracking-tighter leading-[0.8] drop-shadow-sm flex overflow-hidden"
                [style.transform]="'translate(' + mouseX() * 0.2 + 'px, ' + mouseY() * 0.2 + 'px)'">
              @for (char of ['I','D','E','I','A','S']; track $index) {
                <span class="inline-block animate-slide-up" [style.animation-delay]="$index * 0.05 + 's'">{{char}}</span>
              }
            </h1>
          </div>

          <!-- Floating Card 1 (Parallax + Rotate) -->
          <div class="col-span-3 md:col-start-9 md:col-span-3 row-start-2 self-center justify-self-center pointer-events-auto">
             <div class="relative w-32 md:w-56 aspect-[3/4] bg-white rounded shadow-2xl transform rotate-6 animate-[slideUp_1s_cubic-bezier(0.19,1,0.22,1)_0.4s_forwards,float_6s_ease-in-out_infinite] opacity-0 hover:rotate-0 transition-all duration-700 ease-out-expo hover:scale-105 hover:z-20 cursor-pointer overflow-hidden border border-slate-100/50" 
                  [style.transform]="'translate(' + mouseX() * 1.5 + 'px, ' + mouseY() * 1.5 + 'px) rotate(6deg)'">
                <img src="https://images.unsplash.com/photo-1605647540924-852290f6b0d5?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover filter brightness-[1.02]" alt="Papel Premium NS Gráfica">
                <div class="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-2 rounded-sm border border-slate-200 flex flex-col gap-0.5 transform translate-y-10 group-hover:translate-y-0 transition-transform duration-300">
                   <span class="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Material</span>
                   <span class="text-xs font-bold text-slate-900">Papel Couché 300g</span>
                </div>
             </div>
          </div>

          <!-- Word 2: QUE (Reveal Fade) -->
          <div class="col-span-6 md:col-start-8 md:col-span-4 row-start-3 md:row-start-3 flex items-start justify-end md:justify-start">
            <span class="font-serif font-medium italic text-4xl md:text-7xl text-slate-500 mr-8 mix-blend-multiply opacity-0 animate-[slideUp_1s_cubic-bezier(0.19,1,0.22,1)_0.2s_forwards]" 
                  [style.transform]="'translate(' + mouseX() * 0.4 + 'px, ' + mouseY() * 0.4 + 'px)'">
                que
            </span>
          </div>

          <!-- Word 3: GANHAM (Outline Text) -->
          <div class="col-span-6 md:col-start-2 md:col-span-8 row-start-4 md:row-start-4 flex items-start overflow-hidden">
            <h1 class="font-display font-black text-6xl md:text-8xl lg:text-[9rem] text-outline text-transparent tracking-tighter leading-[0.8] opacity-60 flex"
                [style.transform]="'translate(' + mouseX() * 0.6 + 'px, ' + mouseY() * 0.6 + 'px)'">
              @for (char of ['G','A','N','H','A','M']; track $index) {
                <span class="inline-block animate-[slideUp_0.8s_cubic-bezier(0.19,1,0.22,1)_forwards] opacity-0" [style.animation-delay]="$index * 0.05 + 0.3 + 's'">{{char}}</span>
              }
            </h1>
          </div>

          <!-- Floating Card 2 (Badge) -->
          <div class="col-span-3 md:col-start-2 md:col-span-3 row-start-5 self-start justify-self-center pointer-events-auto hidden md:block">
             <div class="relative w-40 h-40 flex items-center justify-center animate-[slideUp_1s_cubic-bezier(0.19,1,0.22,1)_0.6s_forwards] opacity-0 hover:scale-110 transition-transform duration-500" 
                  [style.transform]="'translate(' + mouseX() * 1.2 + 'px, ' + mouseY() * 1.2 + 'px)'">
                <div class="absolute inset-0 animate-spin-reverse-slow">
                   <svg viewBox="0 0 100 100" class="w-full h-full fill-slate-900">
                      <path id="circlePath" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0" fill="transparent" />
                      <text font-size="11.5" font-weight="bold" letter-spacing="1.2">
                         <textPath href="#circlePath" startOffset="0%">
                            NS GRÁFICA • OFFSET & DIGITAL • 
                         </textPath>
                      </text>
                   </svg>
                </div>
                <div class="w-20 h-20 bg-ns-blue rounded-full flex items-center justify-center text-white shadow-lg z-10 hover:bg-ns-yellow hover:text-slate-900 transition-colors duration-300">
                   <svg xmlns="http://www.w3.org/2000/svg" class="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                   </svg>
                </div>
             </div>
          </div>

          <!-- Word 4: FORMA -->
          <div class="col-span-6 md:col-start-5 md:col-span-8 row-start-5 md:row-start-5 flex items-start justify-end md:justify-start">
            <h1 class="font-display font-black text-6xl md:text-8xl lg:text-[10rem] text-ns-blue tracking-tighter leading-[0.8] relative animate-[slideUp_1s_cubic-bezier(0.19,1,0.22,1)_0.5s_forwards] opacity-0"
                [style.transform]="'translate(' + mouseX() * 0.3 + 'px, ' + mouseY() * 0.3 + 'px)'">
              FORMA
              <svg class="absolute -top-6 -right-12 w-16 h-16 text-ns-yellow animate-pulse-slow md:block hidden drop-shadow-md" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 0L14.5 9.5L24 12L14.5 14.5L12 24L9.5 14.5L0 12L9.5 9.5Z" />
              </svg>
            </h1>
          </div>

          <!-- CTA Section (Bounce) -->
          <div class="col-span-6 md:col-start-9 md:col-span-4 row-start-6 flex items-center justify-end animate-[slideUp_1s_cubic-bezier(0.19,1,0.22,1)_0.8s_forwards] opacity-0 pointer-events-auto">
            <a routerLink="/contacto" class="group cursor-pointer flex items-center gap-6 text-slate-900">
              <div class="flex flex-col items-end">
                <span class="relative font-bold text-xl md:text-2xl tracking-tight">
                  Solicitar Orçamento
                  <span class="absolute -bottom-1 left-0 w-0 h-[2px] bg-ns-blue transition-all duration-300 ease-out group-hover:w-full"></span>
                </span>
                <span class="text-xs text-slate-500 font-semibold mt-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300 transform -translate-y-2 group-hover:translate-y-0">Comece seu projeto hoje</span>
              </div>
              
              <div class="w-14 h-14 rounded-full border border-slate-200 bg-white flex items-center justify-center group-hover:border-ns-blue group-hover:bg-ns-blue group-hover:text-white transition-all duration-300 shadow-sm group-hover:shadow-lg group-hover:scale-110 group-hover:animate-vibrate">
                 <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 transform transition-transform duration-300 group-hover:rotate-45" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </div>
            </a>
          </div>

        </div>
      </div>
      
      <!-- Scroll Indicator -->
      <div class="absolute bottom-6 left-6 md:left-1/2 md:-translate-x-1/2 flex flex-col items-center gap-3 opacity-60 mix-blend-multiply animate-float">
         <span class="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500">Scroll</span>
         <div class="w-[1px] h-12 bg-gradient-to-b from-slate-400 to-transparent"></div>
      </div>
    </section>

    <!-- Marquee -->
    <section class="py-12 bg-transparent border-y border-slate-200/50 overflow-hidden">
       <div class="container mx-auto px-6 mb-6">
          <p class="text-center text-slate-400 text-sm font-bold uppercase tracking-widest" appScrollAnimation animationClass="reveal-up animate-active">Empresas que confiam na NS Gráfica</p>
       </div>
       <div class="relative w-full overflow-hidden" appScrollAnimation animationClass="animate-active opacity-100">
          <div class="absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-[#F5F6FA] to-transparent z-10"></div>
          <div class="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-[#F5F6FA] to-transparent z-10"></div>
          
          <div class="flex whitespace-nowrap animate-marquee hover:[animation-play-state:paused]">
             <div class="flex items-center gap-16 mx-8">
                @for(brand of brandsList(); track brand) {
                   <span class="text-2xl md:text-3xl font-display font-black text-slate-300 uppercase hover:text-ns-blue transition-colors cursor-default select-none">{{brand}}</span>
                }
             </div>
             <div class="flex items-center gap-16 mx-8">
                @for(brand of brandsList(); track brand) {
                   <span class="text-2xl md:text-3xl font-display font-black text-slate-300 uppercase hover:text-ns-blue transition-colors cursor-default select-none">{{brand}}</span>
                }
             </div>
          </div>
       </div>
    </section>

    <!-- 2. O QUE FAZEMOS (SERVIÇOS) -->
    <section class="py-32 relative bg-transparent">
      <div class="container mx-auto px-6">
        <div class="grid lg:grid-cols-2 gap-16 mb-16">
           <div class="flex flex-col justify-center" appScrollAnimation animationClass="reveal-mask-left animate-active">
             <span class="text-ns-blue font-bold tracking-[0.2em] text-sm mb-4 uppercase">O Que Fazemos</span>
             <h2 class="text-4xl md:text-6xl font-display font-black text-slate-900 leading-[0.9] mb-8">
               Soluções visuais que <span class="text-transparent bg-clip-text bg-gradient-to-r from-ns-blue to-ns-cyan italic font-serif">impulsionam</span>
             </h2>
           </div>
           <div class="flex items-end lg:justify-end" appScrollAnimation animationClass="reveal-up animate-active" [delay]="200">
              <a routerLink="/portfolio" class="group flex items-center gap-2 text-slate-500 hover:text-ns-blue transition-colors font-bold uppercase tracking-wider text-sm cursor-pointer">
                Ver exemplos no portfólio
                <span class="block w-8 h-[1px] bg-current group-hover:w-16 transition-all duration-300"></span>
              </a>
           </div>
        </div>

        <div class="grid md:grid-cols-3 gap-8 stagger-parent" appScrollAnimation animationClass="animate-active">
          @for (service of editorialServices(); track service.title) {
            <div class="stagger-item group relative bg-white p-8 rounded-2xl shadow-sm hover:shadow-2xl transition-all duration-500 ease-out-expo border border-slate-100 overflow-hidden hover:-translate-y-2">
               <!-- Animated BG Shape -->
               <div class="absolute top-0 right-0 p-6 opacity-10 group-hover:opacity-100 group-hover:scale-110 transition-all duration-700 ease-out-expo transform origin-top-right">
                  <svg [class]="'w-32 h-32 text-ns-blue ' + service.rotateClass" fill="currentColor" viewBox="0 0 24 24">
                     <path d="M12 2L2 7l10 5 10-5-10-5zm0 9l2.5-1.25L12 8.5l-2.5 1.25L12 11zm0 2.5l-5-2.5-5 2.5L12 22l10-8.5-5-2.5-5 2.5z" />
                  </svg>
               </div>
               
               <h3 class="text-2xl font-display font-bold text-slate-900 mb-4 relative z-10 translate-y-2 group-hover:translate-y-0 transition-transform duration-500">{{service.title}}</h3>
               <p class="text-lg text-slate-600 leading-relaxed font-serif italic mb-6 relative z-10">{{service.desc}}</p>
               
               <div class="w-full h-[1px] bg-slate-100 mb-6 group-hover:bg-ns-blue/20 transition-colors"></div>
               
               <ul class="space-y-2 relative z-10">
                 @for (tag of service.tags; track tag) {
                   <li class="text-sm font-bold text-slate-400 uppercase tracking-wider group-hover:text-ns-blue transition-colors translate-x-0 group-hover:translate-x-2 transition-transform duration-300" [style.transition-delay]="$index * 50 + 'ms'">{{tag}}</li>
                 }
               </ul>
            </div>
          }
        </div>
      </div>
    </section>

    <!-- 3. PROVA VISUAL (PORTFÓLIO EM DESTAQUE) -->
    <section class="py-32 bg-slate-900 text-white relative overflow-hidden">
      <!-- Background Texture -->
      <div class="absolute inset-0 opacity-[0.05]" 
             style="background-image: linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px); background-size: 40px 40px;">
      </div>

      <div class="container mx-auto px-6 relative z-10">
        <div class="flex flex-col md:flex-row justify-between items-end mb-16 gap-8" appScrollAnimation animationClass="reveal-up animate-active">
           <div>
             <span class="text-ns-cyan font-bold tracking-[0.2em] text-sm mb-4 uppercase block">Prova Visual</span>
             <h2 class="text-4xl md:text-5xl font-display font-black text-white">
               Qualidade que não <br>precisa de legendas.
             </h2>
           </div>
           <a routerLink="/portfolio" class="px-8 py-3 border border-white/20 rounded-full hover:bg-white hover:text-slate-900 transition-all font-bold text-sm uppercase tracking-wide cursor-pointer hover:scale-105 active:scale-95 duration-300">
             Ver Portfólio Completo
           </a>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 auto-rows-[300px]">
          @for (item of portfolioTeaser(); track item.id; let i = $index) {
            <div class="group relative overflow-hidden rounded-lg cursor-pointer bg-slate-800"
                 [class.md:col-span-2]="i === 0 || i === 3"
                 [class.lg:col-span-2]="i === 0 || i === 3"
                 appScrollAnimation animationClass="reveal-mask-up animate-active"
                 [delay]="i * 100">
               <img [src]="item.img" class="w-full h-full object-cover transition-transform duration-[1.5s] ease-out-expo group-hover:scale-110 opacity-80 group-hover:opacity-100" alt="Portfolio Item">
               <div class="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-80 group-hover:opacity-60 transition-opacity duration-500"></div>
               <div class="absolute bottom-0 left-0 p-8 translate-y-4 group-hover:translate-y-0 transition-transform duration-500 ease-out-back">
                  <span class="text-ns-cyan text-xs font-bold uppercase tracking-widest mb-2 block">{{item.cat}}</span>
                  <h3 class="text-2xl font-display font-bold text-white group-hover:text-ns-yellow transition-colors">{{item.title}}</h3>
               </div>
            </div>
          }
        </div>
      </div>
    </section>

    <!-- 4. COMO TRABALHAMOS (PROCESSO) -->
    <section class="py-24 bg-white border-b border-slate-100">
      <div class="container mx-auto px-6">
        <div class="text-center mb-16 max-w-2xl mx-auto" appScrollAnimation animationClass="reveal-scale animate-active">
          <span class="text-ns-blue font-bold tracking-[0.2em] text-sm mb-4 uppercase block">Processo</span>
          <h2 class="text-3xl md:text-4xl font-display font-bold text-slate-900 mb-6">Do rascunho à realidade</h2>
          <p class="text-slate-500">Simplificamos o complexo para entregar excelência sem dor de cabeça.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-8 relative stagger-parent" appScrollAnimation animationClass="animate-active">
          <!-- Connecting Line (Desktop) -->
          <div class="hidden md:block absolute top-12 left-0 w-full h-[2px] bg-slate-100 -z-0">
             <div class="h-full bg-ns-blue w-0 animate-[width-grow] transition-all duration-1000 delay-500" style="width: 100%"></div> 
             <!-- CSS hack: assuming we want line to grow, handled by parent reveal usually. Static for now -->
          </div>

          @for (step of processSteps(); track step.id) {
            <div class="stagger-item relative z-10 flex flex-col items-center text-center group">
               <div class="w-24 h-24 rounded-full bg-white border-4 border-slate-50 flex items-center justify-center mb-6 group-hover:border-ns-blue transition-colors duration-500 shadow-sm group-hover:scale-110 ease-out-back">
                  <span class="font-display font-black text-3xl text-slate-200 group-hover:text-ns-blue transition-colors">{{step.id}}</span>
               </div>
               <h3 class="text-xl font-bold text-slate-900 mb-2">{{step.title}}</h3>
               <p class="text-sm text-slate-500">{{step.desc}}</p>
            </div>
          }
        </div>
      </div>
    </section>

    <!-- 5. DIFERENCIAIS -->
    <section class="py-24 bg-[#F5F6FA]">
      <div class="container mx-auto px-6">
         <div class="grid md:grid-cols-2 gap-16 items-center">
            <div appScrollAnimation animationClass="reveal-mask-left animate-active">
               <h2 class="text-3xl md:text-4xl font-display font-bold text-slate-900 mb-8">Por que a NS Gráfica?</h2>
               <div class="space-y-8 stagger-parent" appScrollAnimation animationClass="animate-active">
                  @for (diff of refinedDifferentials(); track diff.title) {
                     <div class="stagger-item flex gap-5 group">
                        <div class="flex-shrink-0 w-12 h-12 rounded-lg bg-ns-blue/10 flex items-center justify-center text-ns-blue group-hover:bg-ns-blue group-hover:text-white transition-colors duration-300">
                           <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" [attr.d]="diff.iconPath" />
                           </svg>
                        </div>
                        <div>
                           <h4 class="text-lg font-bold text-slate-900 mb-1 group-hover:text-ns-blue transition-colors">{{diff.title}}</h4>
                           <p class="text-slate-600 text-sm leading-relaxed">{{diff.desc}}</p>
                        </div>
                     </div>
                  }
               </div>
            </div>
            <div class="relative h-full min-h-[400px]" appScrollAnimation animationClass="reveal-scale animate-active" [delay]="200">
               <!-- Abstract visual composition -->
               <div class="absolute top-0 right-0 w-3/4 h-3/4 bg-ns-blue rounded-2xl transform rotate-3 animate-float-random opacity-20"></div>
               <div class="absolute bottom-0 left-0 w-3/4 h-3/4 bg-slate-900 rounded-2xl transform -rotate-2 overflow-hidden shadow-2xl transition-transform duration-700 hover:rotate-0 hover:scale-105">
                  <img src="https://images.unsplash.com/photo-1586717791821-3f44a5638d0f?q=80&w=800&auto=format&fit=crop" class="w-full h-full object-cover opacity-80" alt="Qualidade NS">
               </div>
            </div>
         </div>
      </div>
    </section>

    <!-- 6. CTA FORTE -->
    <section class="py-32 bg-ns-blue text-white text-center relative overflow-hidden">
       <div class="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 animate-pulse-slow"></div>
       <div class="container mx-auto px-6 relative z-10" appScrollAnimation animationClass="reveal-scale animate-active">
          <h2 class="text-4xl md:text-6xl font-display font-black mb-8 leading-tight">
             Pronto para dar forma <br> à sua próxima ideia?
          </h2>
          <div class="flex flex-col md:flex-row gap-6 justify-center items-center">
             <a routerLink="/contacto" class="px-10 py-5 bg-ns-yellow text-slate-900 font-bold text-lg rounded-full shadow-2xl hover:bg-white transition-all transform hover:scale-105 hover:rotate-1 cursor-pointer active:scale-95 animate-bounce" style="animation-duration: 3s">
                Solicitar Orçamento
             </a>
             <span class="text-blue-200 text-sm font-semibold tracking-wide">Sem compromisso. Resposta rápida.</span>
          </div>
       </div>
    </section>
  `
})
export class HomeComponent {
  mouseX = signal(0);
  mouseY = signal(0);

  // 1. Brands Data
  brandsList = signal([
    'Base Sólida', 'DECISIVO', 'AMPÈRE', 'FAST CARRO', 'CWB AÇO', 
    'GREEN LAR', 'BRAINS', 'Brasfalto', 'VAPTY', 'MIM'
  ]);

  // 2. Editorial Services Teaser Data
  editorialServices = signal([
    {
      title: 'Design Gráfico',
      desc: 'Ideias bem pensadas antes de imprimir.',
      tags: ['Branding', 'Editorial', 'Layout'],
      rotateClass: 'rotate-0'
    },
    {
      title: 'Impressão Offset',
      desc: 'Qualidade que se vê e se toca.',
      tags: ['Alta Tiragem', 'Acabamentos', 'Cor Real'],
      rotateClass: 'rotate-12'
    },
    {
      title: 'Comunicação Visual',
      desc: 'Presença física que chama atenção.',
      tags: ['Fachadas', 'Sinalização', 'Grandes Formatos'],
      rotateClass: '-rotate-6'
    }
  ]);

  // 3. Portfolio Teaser Data (Top 4)
  portfolioTeaser = signal([
    { id: 1, title: 'Revista EGO', cat: 'Editorial', img: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?q=80&w=800&auto=format&fit=crop' },
    { id: 2, title: 'Café Origem', cat: 'Embalagem', img: 'https://images.unsplash.com/photo-1632515902189-e1cd3f274a13?q=80&w=800&auto=format&fit=crop' },
    { id: 3, title: 'BRAINS Tech', cat: 'Branding', img: 'https://images.unsplash.com/photo-1600607686527-6fb886090705?q=80&w=800&auto=format&fit=crop' },
    { id: 4, title: 'VAPTY Frotas', cat: 'Sinalização', img: 'https://images.unsplash.com/photo-1629427042301-38aa7363404c?q=80&w=800&auto=format&fit=crop' }
  ]);

  // 4. Process Data
  processSteps = signal([
    { id: 1, title: 'Ideia', desc: 'Entendemos a sua necessidade.' },
    { id: 2, title: 'Criação', desc: 'Design estratégico e aprovado.' },
    { id: 3, title: 'Produção', desc: 'Impressão com tecnologia de ponta.' },
    { id: 4, title: 'Entrega', desc: 'No prazo combinado, onde estiver.' }
  ]);

  // 5. Refined Differentials
  refinedDifferentials = signal([
    { 
      title: 'Tudo num só lugar', 
      desc: 'Do design à entrega final, centralizamos o processo para garantir consistência.',
      iconPath: 'M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10'
    },
    { 
      title: 'Acabamento profissional', 
      desc: 'Verniz, corte especial, hot stamping. Detalhes que elevam o valor percebido.',
      iconPath: 'M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z'
    },
    { 
      title: 'Prazos cumpridos', 
      desc: 'Respeitamos o seu cronograma. Sabemos que em negócios, tempo é dinheiro.',
      iconPath: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z'
    },
    { 
      title: 'Atendimento próximo', 
      desc: 'Consultores reais prontos para resolver, no WhatsApp ou presencialmente.',
      iconPath: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z'
    }
  ]);

  @HostListener('mousemove', ['$event'])
  onMouseMove(event: MouseEvent) {
    if (typeof window !== 'undefined') {
      const x = (event.clientX - window.innerWidth / 2) / 50;
      const y = (event.clientY - window.innerHeight / 2) / 50;
      this.mouseX.set(x);
      this.mouseY.set(y);
    }
  }
}
